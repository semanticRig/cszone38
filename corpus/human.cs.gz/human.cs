using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Orders;

public sealed class OrderService
{
    public OrderService(IReadOnlyList<Order> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Order> Items { get; }

    public Order? CreateOrder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Id?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Id))
        {
            yield return $"Orders:Order:{item.Id}";
        }
    }
}

public sealed record Order(Guid Id, string? Id, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Accounts;

public sealed class InvoiceHandler
{
    public InvoiceHandler(IReadOnlyList<Invoice> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Invoice> Items { get; }

    public Invoice? UpdateInvoice(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Status?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Status))
        {
            yield return $"Accounts:Invoice:{item.Status}";
        }
    }
}

public sealed record Invoice(Guid Id, string? Status, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Billing;

public sealed class CustomerParser
{
    public CustomerParser(IReadOnlyList<Customer> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Customer> Items { get; }

    public Customer? DeleteCustomer(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Total?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Total))
        {
            yield return $"Billing:Customer:{item.Total}";
        }
    }
}

public sealed record Customer(Guid Id, string? Total, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Inventory;

public sealed class ShipmentFormatter
{
    public ShipmentFormatter(IReadOnlyList<Shipment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Shipment> Items { get; }

    public Shipment? ArchiveShipment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.CreatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.CreatedAt))
        {
            yield return $"Inventory:Shipment:{item.CreatedAt}";
        }
    }
}

public sealed record Shipment(Guid Id, string? CreatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Shipping;

public sealed class UserValidator
{
    public UserValidator(IReadOnlyList<User> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<User> Items { get; }

    public User? RestoreUser(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.UpdatedAt?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.UpdatedAt))
        {
            yield return $"Shipping:User:{item.UpdatedAt}";
        }
    }
}

public sealed record User(Guid Id, string? UpdatedAt, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Support;

public sealed class TicketCoordinator
{
    public TicketCoordinator(IReadOnlyList<Ticket> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Ticket> Items { get; }

    public Ticket? ShipTicket(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Code?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Code))
        {
            yield return $"Support:Ticket:{item.Code}";
        }
    }
}

public sealed record Ticket(Guid Id, string? Code, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Identity;

public sealed class ProductMapper
{
    public ProductMapper(IReadOnlyList<Product> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Product> Items { get; }

    public Product? ApproveProduct(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Reference?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Reference))
        {
            yield return $"Identity:Product:{item.Reference}";
        }
    }
}

public sealed record Product(Guid Id, string? Reference, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Catalog;

public sealed class SubscriptionStore
{
    public SubscriptionStore(IReadOnlyList<Subscription> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Subscription> Items { get; }

    public Subscription? RejectSubscription(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.OwnerId?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.OwnerId))
        {
            yield return $"Catalog:Subscription:{item.OwnerId}";
        }
    }
}

public sealed record Subscription(Guid Id, string? OwnerId, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Pricing;

public sealed class PaymentGateway
{
    public PaymentGateway(IReadOnlyList<Payment> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Payment> Items { get; }

    public Payment? PublishPayment(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Region?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Region))
        {
            yield return $"Pricing:Payment:{item.Region}";
        }
    }
}

public sealed record Payment(Guid Id, string? Region, decimal Total);

using System;
using System.Collections.Generic;
using System.Linq;

namespace Contoso.Returns;

public sealed class QuoteProjection
{
    public QuoteProjection(IReadOnlyList<Quote> items)
    {
        Items = items ?? throw new ArgumentNullException(nameof(items));
    }

    public IReadOnlyList<Quote> Items { get; }

    public Quote? AssignQuote(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;

        return Items.FirstOrDefault(item =>
            string.Equals(item.Channel?.ToString(), value, StringComparison.OrdinalIgnoreCase));
    }

    public IEnumerable<string> Summaries()
    {
        foreach (var item in Items.OrderBy(item => item.Channel))
        {
            yield return $"Returns:Quote:{item.Channel}";
        }
    }
}

public sealed record Quote(Guid Id, string? Channel, decimal Total);

